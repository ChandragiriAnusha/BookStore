
import java.io.*;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.http.*;

public class LoginServlet extends HttpServlet {

    @Override
    public void init() {
    }

    @Override
    public void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        try {
            PrintWriter out = res.getWriter();
            String u = req.getParameter("user");
            String p = req.getParameter("pass");
            int count = 0;
            out.println("<html><head><style>");
            out.println("div.st{"
                    + " text-align: center;"
                    + "  padding-top: 200px;"
                    + "  padding-bottom: 200px;"
                    + "  border:3px solid grey;"
                    + "  line-height: 50px;"
                    + "  }" + "</style>"
                    + "</head>");
            out.println("<form>");
            if (u == "") {
                out.println("<script>");
                out.println("alert('Enter Username please');");
                out.println("location='index.html'");
                out.println("</script>");
                
            }
            // out.println("name:"+u);
            //out.println("password:"+p);
            Class.forName("org.postgresql.Driver");
            Connection c = DriverManager.getConnection("jdbc:postgresql://localhost:5432/postgres", "postgres", "ragini");
            Statement st = c.createStatement();
            ResultSet rs = st.executeQuery("select * from log");
            while (rs.next()) {
                String valuser = rs.getString(1);
                String valpass = rs.getString(2);
                if (valuser.equals(u) && valpass.equals(p)) {
                    count = 1;
                }
            }
            if (count == 0) {
                out.println("Recheck ur username and password");
               
            } else {
                out.println("<div class:st>");
                out.println("name:" + u + "<br>");
                out.println("password:" + p + "<br>");
                out.println("LoginSucessful");
                out.println("</div>");
            }

            out.println("</form></html>");
        } catch (SQLException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(LoginServlet.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
}
